package com.tu.stickerapp

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class StickerConverter {

    fun convertToAnimatedWebP(
        context: Context,
        inputUri: Uri,
        maxDurationMs: Long = 3000L,
        fps: Int = 15,
        sizePx: Int = 512
    ): String? {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, inputUri)

            val durationMs = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: maxDurationMs

            val clipMs = minOf(durationMs, maxDurationMs)
            val totalFrames = (clipMs * fps / 1000L).toInt().coerceAtLeast(1)
            val frameDelayMs = (1000.0 / fps).toLong()

            val frames = mutableListOf<Bitmap>()
            for (i in 0 until totalFrames) {
                val timeUs = i.toLong() * 1_000_000L / fps
                val raw = retriever.getFrameAtTime(
                    timeUs,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                ) ?: continue
                frames.add(scaleCenterCrop(raw, sizePx))
                raw.recycle()
            }
            retriever.release()

            if (frames.isEmpty()) return null

            val outFile = File(context.cacheDir, "sticker_animated.webp")
            buildAnimatedWebP(frames, outFile, frameDelayMs.toInt())
            frames.forEach { it.recycle() }

            outFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun scaleCenterCrop(src: Bitmap, sizePx: Int): Bitmap {
        val scale = maxOf(sizePx.toFloat() / src.width, sizePx.toFloat() / src.height)
        val w = (src.width * scale).toInt()
        val h = (src.height * scale).toInt()
        val scaled = Bitmap.createScaledBitmap(src, w, h, true)
        val x = (w - sizePx) / 2
        val y = (h - sizePx) / 2
        val cropped = Bitmap.createBitmap(scaled, x, y, sizePx, sizePx)
        if (scaled != src) scaled.recycle()
        return cropped
    }

    private fun buildAnimatedWebP(frames: List<Bitmap>, outFile: File, frameDelayMs: Int) {
        // Encode each frame as a single WebP, then strip the RIFF header to get raw VP8 chunk
        val vp8Chunks = frames.map { bmp ->
            val baos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.WEBP_LOSSY, 80, baos)
            stripToVP8Chunk(baos.toByteArray())
        }

        val width = frames[0].width
        val height = frames[0].height

        val payload = ByteArrayOutputStream()

        fun le32(v: Int) = byteArrayOf(
            (v and 0xFF).toByte(), ((v shr 8) and 0xFF).toByte(),
            ((v shr 16) and 0xFF).toByte(), ((v shr 24) and 0xFF).toByte()
        )
        fun le24(v: Int) = byteArrayOf(
            (v and 0xFF).toByte(), ((v shr 8) and 0xFF).toByte(), ((v shr 16) and 0xFF).toByte()
        )
        fun le16(v: Int) = byteArrayOf((v and 0xFF).toByte(), ((v shr 8) and 0xFF).toByte())
        fun tag(s: String) = s.toByteArray(Charsets.US_ASCII)

        fun chunk(name: String, data: ByteArray) {
            payload.write(tag(name))
            payload.write(le32(data.size))
            payload.write(data)
            if (data.size % 2 != 0) payload.write(0)
        }

        // VP8X: flags(4) + canvasW-1(3) + canvasH-1(3) = 10 bytes
        chunk("VP8X", le32(0x00000002) + le24(width - 1) + le24(height - 1))

        // ANIM: bgcolor(4) + loop_count(2) = 6 bytes
        chunk("ANIM", le32(0xFFFFFFFF.toInt()) + le16(0))

        // ANMF per frame
        for (vp8 in vp8Chunks) {
            val anmfData =
                le24(0) +                    // X / 2
                le24(0) +                    // Y / 2
                le24((width / 2) - 1) +      // W / 2 - 1
                le24((height / 2) - 1) +     // H / 2 - 1
                le24(frameDelayMs) +         // duration ms
                byteArrayOf(0) +             // flags
                vp8                          // VP8 bitstream chunk
            chunk("ANMF", anmfData)
        }

        val payloadBytes = payload.toByteArray()
        val riff = ByteArrayOutputStream()
        riff.write(tag("RIFF"))
        riff.write(le32(4 + payloadBytes.size))
        riff.write(tag("WEBP"))
        riff.write(payloadBytes)

        FileOutputStream(outFile).use { it.write(riff.toByteArray()) }
    }

    // Strips RIFF/WEBP header from a single-frame WebP, returns the inner VP8/VP8L chunk
    private fun stripToVP8Chunk(webpBytes: ByteArray): ByteArray {
        var i = 12 // skip RIFF(4) + size(4) + WEBP(4)
        while (i < webpBytes.size - 8) {
            val t = String(webpBytes, i, 4, Charsets.US_ASCII)
            val sz = (webpBytes[i+4].toInt() and 0xFF) or
                     ((webpBytes[i+5].toInt() and 0xFF) shl 8) or
                     ((webpBytes[i+6].toInt() and 0xFF) shl 16) or
                     ((webpBytes[i+7].toInt() and 0xFF) shl 24)
            if (t == "VP8 " || t == "VP8L") return webpBytes.copyOfRange(i, i + 8 + sz)
            i += 8 + sz + (sz % 2)
        }
        return webpBytes.copyOfRange(12, webpBytes.size)
    }
}

private operator fun ByteArray.plus(other: ByteArray): ByteArray {
    val r = ByteArray(size + other.size)
    copyInto(r); other.copyInto(r, size)
    return r
}
