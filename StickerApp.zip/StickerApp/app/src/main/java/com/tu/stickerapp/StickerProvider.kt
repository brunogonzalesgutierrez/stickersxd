package com.tu.stickerapp

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.AssetFileDescriptor
import android.os.ParcelFileDescriptor
import java.io.File

class StickerProvider : ContentProvider() {

    companion object {
        const val AUTHORITY = "com.tu.stickerapp.stickercontentprovider"
        private const val METADATA_CODE            = 1
        private const val METADATA_CODE_FOR_SINGLE = 2
        private const val STICKERS_CODE            = 3
        private const val STICKER_FILE_CODE        = 4
    }

    private val uriMatcher = UriMatcher(UriMatcher.NO_MATCH).also {
        it.addURI(AUTHORITY, "metadata",           METADATA_CODE)
        it.addURI(AUTHORITY, "metadata/*",         METADATA_CODE_FOR_SINGLE)
        it.addURI(AUTHORITY, "stickers/*",         STICKERS_CODE)
        it.addURI(AUTHORITY, "stickers_asset/*/*", STICKER_FILE_CODE)
    }

    override fun onCreate(): Boolean = true

    override fun query(
        uri: Uri, projection: Array<String>?,
        selection: String?, selectionArgs: Array<String>?, sortOrder: String?
    ): Cursor {
        return when (uriMatcher.match(uri)) {
            METADATA_CODE, METADATA_CODE_FOR_SINGLE -> buildMetadataCursor()
            STICKERS_CODE -> buildStickersCursor()
            else -> MatrixCursor(arrayOf())
        }
    }

    private fun buildMetadataCursor(): MatrixCursor {
        val cols = arrayOf(
            "sticker_pack_id", "sticker_pack_name", "sticker_pack_publisher",
            "sticker_pack_tray_image", "android_play_store_link", "ios_app_store_link",
            "image_data_version", "avoid_cache", "animated_sticker_pack"
        )
        val cursor = MatrixCursor(cols)
        cursor.addRow(arrayOf("mi_pack_1", "Mi Pack", "Yo", "tray.webp", "", "", "1", 0, 1))
        return cursor
    }

    private fun buildStickersCursor(): MatrixCursor {
        val cursor = MatrixCursor(arrayOf("sticker_file_name", "sticker_emoji"))
        cursor.addRow(arrayOf("sticker_animated.webp", "😄,🎬"))
        return cursor
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        if (uriMatcher.match(uri) != STICKER_FILE_CODE) return null
        val filename = uri.lastPathSegment ?: return null
        val file = File(context!!.cacheDir, filename)
        if (!file.exists()) return null
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        return AssetFileDescriptor(pfd, 0, AssetFileDescriptor.UNKNOWN_LENGTH)
    }

    override fun getType(uri: Uri): String = "image/webp"
    override fun insert(uri: Uri, values: ContentValues?) = null
    override fun delete(uri: Uri, s: String?, a: Array<String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<String>?) = 0
}
