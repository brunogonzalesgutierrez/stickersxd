package com.tu.stickerapp

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.AnimatedImageDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var imgPreview:    ImageView
    private lateinit var tvPlaceholder: TextView
    private lateinit var tvStatus:      TextView
    private lateinit var progressBar:   ProgressBar
    private lateinit var btnPick:       Button
    private lateinit var btnConvert:    Button
    private lateinit var btnSend:       Button
    private lateinit var seekDuration:  SeekBar
    private lateinit var tvDuration:    TextView

    private var selectedUri:    Uri?    = null
    private var outputWebPPath: String? = null
    private val converter = StickerConverter()

    private val durationSteps = floatArrayOf(1f, 1.5f, 2f, 2.5f, 3f)

    private val pickMedia = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        selectedUri = uri
        outputWebPPath = null
        btnSend.isEnabled = false
        btnConvert.isEnabled = true
        setStatus("Video seleccionado ✓ — Tocá CONVERTIR")
        tvPlaceholder.text = "📹"
        tvPlaceholder.visibility = View.VISIBLE
        imgPreview.setImageDrawable(null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imgPreview    = findViewById(R.id.imgPreview)
        tvPlaceholder = findViewById(R.id.tvPlaceholder)
        tvStatus      = findViewById(R.id.tvStatus)
        progressBar   = findViewById(R.id.progressBar)
        btnPick       = findViewById(R.id.btnPick)
        btnConvert    = findViewById(R.id.btnConvert)
        btnSend       = findViewById(R.id.btnSend)
        seekDuration  = findViewById(R.id.seekDuration)
        tvDuration    = findViewById(R.id.tvDuration)

        seekDuration.max = durationSteps.size - 1
        seekDuration.progress = durationSteps.size - 1
        tvDuration.text = "${durationSteps.last().toInt()}s"

        seekDuration.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                val s = durationSteps[p]
                tvDuration.text = if (s == s.toInt().toFloat()) "${s.toInt()}s" else "${s}s"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        btnPick.setOnClickListener    { pickMedia.launch("video/*") }
        btnConvert.setOnClickListener { startConvert() }
        btnSend.setOnClickListener    { sendToWhatsApp() }
    }

    private fun startConvert() {
        val uri = selectedUri ?: return
        val durationMs = (durationSteps[seekDuration.progress] * 1000).toLong()

        lifecycleScope.launch {
            setLoading(true)
            setStatus("Extrayendo frames...")

            val result = withContext(Dispatchers.IO) {
                converter.convertToAnimatedWebP(
                    context       = applicationContext,
                    inputUri      = uri,
                    maxDurationMs = durationMs,
                    fps           = 15,
                    sizePx        = 512
                )
            }

            setLoading(false)

            if (result != null) {
                outputWebPPath = result
                val sizeKb = File(result).length() / 1024
                setStatus("Sticker listo ✓  ($sizeKb KB)")
                tvPlaceholder.visibility = View.GONE
                imgPreview.setImageURI(Uri.fromFile(File(result)))
                if (Build.VERSION.SDK_INT >= 28) {
                    (imgPreview.drawable as? AnimatedImageDrawable)?.start()
                }
                btnSend.isEnabled = true
            } else {
                setStatus("❌ Error al convertir. Probá con otro video.")
            }
        }
    }

    private fun sendToWhatsApp() {
        outputWebPPath ?: return
        val waInstalled = listOf("com.whatsapp", "com.whatsapp.w4b").any {
            try { packageManager.getPackageInfo(it, 0); true } catch (e: Exception) { false }
        }
        if (!waInstalled) {
            Toast.makeText(this, "WhatsApp no está instalado", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK").apply {
            putExtra("sticker_pack_id",             "mi_pack_1")
            putExtra("sticker_pack_name",           "Mi Pack")
            putExtra("sticker_pack_authority",      StickerProvider.AUTHORITY)
            putExtra("sticker_pack_localized_name", "Mi Pack")
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQUEST_CODE_ADD_PACK)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir WhatsApp", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_ADD_PACK) {
            if (resultCode == Activity.RESULT_CANCELED) {
                val error = data?.getStringExtra("validation_error")
                setStatus(if (error != null) "WA: $error" else "Cancelado")
            } else {
                setStatus("✅ ¡Pack agregado a WhatsApp!")
                Toast.makeText(this, "¡Sticker agregado!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        btnPick.isEnabled    = !loading
        btnConvert.isEnabled = !loading
        btnSend.isEnabled    = false
    }

    private fun setStatus(msg: String) { tvStatus.text = msg }

    companion object {
        private const val REQUEST_CODE_ADD_PACK = 200
    }
}
